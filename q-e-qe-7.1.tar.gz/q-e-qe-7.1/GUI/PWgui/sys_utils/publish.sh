#!/bin/sh

# usage: $0 file

scp $@ tone@crystal.ijs.si:/var/www/kokalj/pwgui/download
