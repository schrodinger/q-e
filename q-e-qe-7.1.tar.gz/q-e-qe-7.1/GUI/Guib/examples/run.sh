#!/bin/sh

for test in *.tcl 
  do 
  ../guib $test; 
done