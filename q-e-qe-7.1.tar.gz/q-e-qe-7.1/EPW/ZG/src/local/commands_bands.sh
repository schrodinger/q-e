#./compile_commands.sh
/path_to_qe/EPW/ZG_displacement/src/local/kpoints_band_str_unfold.x < input_kpoints.in > kpoints.dat
