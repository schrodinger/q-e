rm -r results *.out *.dat ld1*
